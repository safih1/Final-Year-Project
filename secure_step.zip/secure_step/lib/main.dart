import 'package:flutter/material.dart';
import 'secure_step_app.dart';

void main() {
  runApp(const SecureStepApp());
}